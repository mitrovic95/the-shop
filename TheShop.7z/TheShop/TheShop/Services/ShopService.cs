﻿using System;
using System.Collections.Generic;
using System.Linq;
using TheShop.Database;
using TheShop.Exceptions;
using TheShop.Models;

namespace TheShop.Services
{
    public class ShopService
    {
        private readonly DatabaseDriver driver;

        public ShopService()
        {
            driver = new DatabaseDriver();
        }

        public void AddDummyData()
        {
            var supplier1 = new Supplier()
            {
                Id = 1,
                Name = "Supplier 1"
            };

            var supplier2 = new Supplier()
            {
                Id = 2,
                Name = "Supplier 1"
            };


            var supplier3 = new Supplier()
            {
                Id = 3,
                Name = "Supplier 1"
            };

            driver.Save(new [] {supplier1, supplier2, supplier3 });

            var buyer1 = new Buyer()
            {
                Id = 1,
                Name = "Buyer 1"
            };

            driver.Save(buyer1);

            var article1 = new Article()
            {
                Id = 1,
                SellerId = supplier3.Id,
                Name = "Article 1",
                Price = 458
            };

            var article2 = new Article()
            {
                Id = 2,
                SellerId = supplier2.Id,
                Name = "Article 2",
                Price = 459
            };

            var article3 = new Article()
            {
                Id = 3,
                SellerId = supplier2.Id,
                Name = "Article 3",
                Price = 460
            };

            var article4 = new Article()
            {
                Id = 4,
                SellerId = supplier1.Id,
                Name = "Article 4",
                Price = 461
            };

            driver.Save(new[] { article1, article2, article3, article4 });

            driver.Save(new[] { supplier1, supplier2, supplier3 });
        }

        public bool PlaceOrder(int maxPrice, int buyerId)
        {
            // get buyer entity
            var selectedBuyer = driver.GetAll<Buyer>()
                .Where(buyer => buyer.Id == buyerId)
                .FirstOrDefault();

            if (selectedBuyer == null)
            {
                throw new UnableToFindBuyerException($"Buyer with id {buyerId} does not exists");
            }

            // get articles from suppliers
            var articleToSell = driver.GetAll<Supplier>()
                .SelectMany(article => article.Articles) // flatten
                .Where(article => !article.IsSold && article.Price <= maxPrice)
                .OrderBy(article => article.Price)
                .FirstOrDefault();

            if (articleToSell == null)
            {
                throw new UnableToFindArticleException("Unable to find article with required price condition");
            }

            // is already sold ?
            if (articleToSell.IsSold)
            {
                throw new ArticleAlreadySoldException(articleToSell.Id);
            }

            // sell it to
            articleToSell.IsSold = true;
            articleToSell.SoldDate = DateTime.Now;
            articleToSell.BuyerId = selectedBuyer.Id;

            driver.Save(articleToSell);

            return true;
        }

        public IEnumerable<Article> GetAllArticlesSortedByPriceDescending()
        {
            return driver.GetAll<Article>().OrderByDescending(a => a.Price);
        }

        public Article GetArticleById(int id)
        {
            return driver.GetAll<Article>()
                .Where(article => article.Id == id)
                .FirstOrDefault();
        }

    }
}