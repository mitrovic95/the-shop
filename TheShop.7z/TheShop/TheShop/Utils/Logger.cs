﻿using System;

namespace TheShop.Utils
{
    public static class LoggerFactory
    {
        public static Logger GetLogger()
        {
            return new Logger();
        }

        public class Logger
        {
            public void Trace(string message)
            {
                Console.WriteLine(message);
            }

            public void Info(string message)
            {
                Console.WriteLine("Info: " + message);
            }

            public void Error(string message)
            {
                Console.WriteLine("Error: " + message);
            }

            public void Error(System.Exception ex)
            {
                if (ex != null)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return;
                }

                Console.WriteLine("Unknown exception");
            }

            public void Debug(string message)
            {
                Console.WriteLine("Debug: " + message);
            }
        }
    }
}
