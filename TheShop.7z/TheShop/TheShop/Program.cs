﻿using System;
using TheShop.Services;
using TheShop.Utils;

namespace TheShop
{
	internal class Program
	{
		private static void Main(string[] args)
        {
            var service = new ShopService();

            var logger = LoggerFactory.GetLogger();

            service.AddDummyData();

            try
            {
                service.PlaceOrder(458, 1);

                logger.Trace("Article sold");
            }
            catch (System.Exception ex)
            {
                logger.Error(ex);
            }

            logger.Trace(Environment.NewLine);

            try
            {
                service.PlaceOrder(100, 1);
            }
            catch (System.Exception ex)
            {
                logger.Error(ex);
            }

            logger.Trace(Environment.NewLine);

            // print all articles
            try
            {
                logger.Trace("All Articles list:");

                var articles = service.GetAllArticlesSortedByPriceDescending();

                foreach (var article in articles)
                {
                    logger.Trace($"Article\t{article.Name}\tprice {article.Price}\tstatus {article.IsSold}");
                }
            }
            catch (System.Exception ex)
            {
                logger.Error(ex);
            }

            logger.Trace(Environment.NewLine);

            // print all articles
            try
            {
                logger.Trace("Find article with id = 3");

                var article = service.GetArticleById(3);

                logger.Trace($"Article:\t{article.Name}\tprice {article.Price}\tis sold {article.IsSold}");

                logger.Trace("Article found");
            }
            catch (System.Exception ex)
            {
                logger.Trace("Article not found");
                logger.Error(ex);
            }

            logger.Trace(Environment.NewLine);

            try
            {
                logger.Trace("Find article with id = 42");

                var article = service.GetArticleById(42);

                logger.Trace($"Article:\t{article.Name}\tprice {article.Price}\tstatus {article.IsSold}");

                logger.Trace("Article found");
            }
            catch (System.Exception ex)
            {
                logger.Trace("Article not found");
                logger.Error(ex);
            }
            
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
		}
	}
}