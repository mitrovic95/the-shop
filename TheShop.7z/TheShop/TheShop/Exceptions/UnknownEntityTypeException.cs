﻿namespace TheShop.Exceptions
{
    public class UnknownEntityTypeException : System.Exception
    {
        public UnknownEntityTypeException() : base("Specified entity type is not supported", null)
        {

        }
    }
}