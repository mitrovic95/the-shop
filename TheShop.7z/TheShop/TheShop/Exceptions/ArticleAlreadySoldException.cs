﻿namespace TheShop.Exceptions
{
    public class ArticleAlreadySoldException : System.Exception
    {
        public ArticleAlreadySoldException(int id) : base($"Article with specified id {id} is sold", null)
        {

        }
    }

}
