﻿namespace TheShop.Exceptions
{
    public class UnableToFindBuyerException : System.Exception
    {
        public UnableToFindBuyerException(string message) : base(message, null)
        {

        }
    }
}