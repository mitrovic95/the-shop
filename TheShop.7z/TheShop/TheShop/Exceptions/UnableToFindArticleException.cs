﻿namespace TheShop.Exceptions
{
    public class UnableToFindArticleException : System.Exception
    {
        public UnableToFindArticleException(string message) : base(message, null)
        {

        }
    }
}