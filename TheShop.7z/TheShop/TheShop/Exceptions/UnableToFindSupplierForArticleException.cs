﻿namespace TheShop.Exceptions
{
    public class UnableToFindSupplierForArticleException : System.Exception
    {
        public UnableToFindSupplierForArticleException(string message) : base(message, null)
        {

        }
    }
}