﻿using System;
using TheShop.Database;

namespace TheShop.Models
{
    [Serializable]
    public class Article : StorageEntity
    {
        public string Name { get; set; }

        public int Price { get; set; }

        public bool IsSold { get; set; }

        public DateTime SoldDate { get; set; }

        public int BuyerId { get; set; }

        public int SellerId { get; set; }
    }
}