﻿using System;
using TheShop.Database;

namespace TheShop.Models
{
    [Serializable]
    public class Buyer: StorageEntity
    {
        public string Name { get; set; }
    }
}