﻿using System;
using System.Collections.Generic;
using TheShop.Database;

namespace TheShop.Models
{
    [Serializable]
    public class Supplier : StorageEntity
    {
        public string Name { get; set; }

        public IEnumerable<Article> Articles { get; set; }
    }
}
