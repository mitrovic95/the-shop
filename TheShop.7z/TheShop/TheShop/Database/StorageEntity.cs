﻿using System;

namespace TheShop.Database
{
    [Serializable]
    public class StorageEntity
    {
        public int Id { get; set; }
    }
}