﻿using System.Collections.Generic;
using System.Linq;
using TheShop.Exceptions;
using TheShop.Models;

namespace TheShop.Database
{
    public class DatabaseDriver
    {
        private readonly StorageEngine storage;

        public DatabaseDriver()
        {
            storage = StorageEngine.GetStorageEngine();
        }

        public IQueryable<T> GetAll<T>() where T : StorageEntity
        {
            if (typeof(T) == typeof(Article))
            {
                return storage.Articles.Values.Select(x => x.DeepClone() as T).AsQueryable();
            }
            else if(typeof(T) == typeof(Buyer))
            {
                return storage.Buyers.Values.Select(x => x.DeepClone() as T).AsQueryable();
            }
            else if (typeof(T) == typeof(Supplier))
            {
                var suppliers = storage.Suppliers.Values.Select(x => x.DeepClone() as T);

                // ref. integrity
                var result = suppliers.Select(s =>
                {
                    var tmp = (s as Supplier);
                    tmp.Articles = storage.Articles.Values
                        .Where(a => a.SellerId == s.Id)
                        .Select(a => a.DeepClone())
                        .ToList();
                    return tmp as T;
                });

                return result.AsQueryable();
            }
            else
            {
                throw new UnknownEntityTypeException();
            }
        }

        public void Save(IEnumerable<StorageEntity> entities)
        {
            foreach (var storageEntity in entities)
            {
                Save(storageEntity);
            }
        }

        public void Save(StorageEntity entity)
        {
            switch (entity)
            {
                case Article article:
                {
                    storage.Articles[article.Id] = article.DeepClone();
                    break;
                }
                case Buyer buyer:
                {
                    storage.Buyers[buyer.Id] = buyer.DeepClone();
                    break;
                }
                case Supplier supplier:
                {
                    storage.Suppliers[supplier.Id] = supplier.DeepClone();
                    break;
                }
                default:
                {
                    throw new UnknownEntityTypeException();
                }
            }
        }
    }
}