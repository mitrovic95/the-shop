﻿using System.Collections.Generic;
using TheShop.Models;

namespace TheShop.Database
{
    // This should be placed with driver in separate assembly
    internal class StorageEngine
    {
        private static readonly StorageEngine Instance = new StorageEngine();

        public Dictionary<int, Article> Articles = new Dictionary<int, Article>();

        public Dictionary<int, Buyer> Buyers = new Dictionary<int, Buyer>();

        public Dictionary<int, Supplier> Suppliers = new Dictionary<int, Supplier>();

        public static StorageEngine GetStorageEngine()
        {
            return Instance;
        }

        private StorageEngine()
        {

        }
    }
}